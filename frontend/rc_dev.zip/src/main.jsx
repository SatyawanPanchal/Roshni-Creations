import "./assets/index.css";
import { PrimeReactProvider } from "primereact/api";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";

// prime react installation
import "primeicons/primeicons.css";
import "primereact/resources/themes/lara-dark-amber/theme.css";
import { BrowserRouter } from "react-router-dom";

createRoot(document.getElementById("root")).render(
  <PrimeReactProvider>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </PrimeReactProvider>,
);
