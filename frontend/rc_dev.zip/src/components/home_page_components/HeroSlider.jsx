import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Carousel } from "primereact/carousel";
import { Button } from "primereact/button";
import { motion } from "framer-motion";
import { heroSlides } from "../../data/heroSlides.js";

const SLIDE_DURATION = 5500;

export default function HeroSlider() {
  /**
   * ----------------------------------------
   * HERO SLIDE TEMPLATE
   * ----------------------------------------
   */
  const slideTemplate = (slide) => {
    return (
      <article
        className="
          tw:relative
          tw:h-[clamp(500px,80vh,850px)]
          tw:min-h-125
          tw:w-full
          tw:overflow-hidden
        "
      >
        {/* =========================================
            BACKGROUND IMAGE
        ========================================= */}
        <div className="tw:absolute tw:inset-0">
          <img
            src={slide.image}
            alt={`${slide.heading} ${slide.highlight}`}
            loading="eager"
            draggable="false"
            className="
              tw:h-full
              tw:w-full
              tw:select-none
              tw:object-cover
              tw:object-center
            "
          />
        </div>

        {/* =========================================
            DARK OVERLAY
        ========================================= */}
        <div
          aria-hidden="true"
          className="
            tw:absolute
            tw:inset-0
            tw:bg-linear-to-r
            tw:from-black/65
            tw:via-black/35
            tw:to-black/5
          "
        />

        {/* =========================================
            BOTTOM GRADIENT
        ========================================= */}
        <div
          aria-hidden="true"
          className="
            tw:absolute
            tw:inset-x-0
            tw:bottom-0
            tw:h-[45%]
            tw:bg-linear-to-t
            tw:from-black/55
            tw:to-transparent
          "
        />

        {/* =========================================
            CONTENT CONTAINER

            IMPORTANT:
            No left-40 / left-20 / fixed positioning.
        ========================================= */}
        <div
          className="
            tw:relative
            tw:z-10
            tw:mx-auto
            tw:flex
            tw:h-full
            tw:w-full
            tw:max-w-[1600px]
            tw:items-center
            tw:px-5
            tw:sm:px-8
            tw:md:px-12
            tw:lg:px-16
            tw:xl:px-20
            tw:2xl:px-24
            tw:lg:left-28
            tw:bottom-18
          "
        >
          <motion.div
            key={slide.id}
            initial={{
              opacity: 0,
              x: -30,
            }}
            animate={{
              opacity: 1,
              x: 0,
            }}
            transition={{
              duration: 0.8,
              ease: [0.22, 1, 0.36, 1],
            }}
            className="
              tw:w-full
              tw:max-w-170
              tw:flex
              tw:flex-col
              tw:gap-6
            "
          >
            {/* =========================================
                EYEBROW
            ========================================= */}
            <motion.p
              initial={{
                opacity: 0,
                y: 15,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              transition={{
                duration: 0.6,
                delay: 0.15,
              }}
              className="
                tw:mb-3
                tw:text-[10px]
                tw:font-medium
                tw:uppercase
                tw:tracking-[0.28em]
                tw:text-white/90
                tw:sm:mb-4
                tw:sm:text-[11px]
              "
            >
              {slide.eyebrow}
            </motion.p>

            {/* =========================================
                HEADING
            ========================================= */}
            <motion.h1
              initial={{
                opacity: 0,
                y: 25,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              transition={{
                duration: 0.75,
                delay: 0.25,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="
                tw:m-0
                tw:max-w-170
                tw:font-serif
                tw:text-[clamp(42px,7vw,82px)]
                tw:font-normal
                tw:leading-[0.98]
                tw:tracking-[-0.02em]
                tw:text-white
              "
            >
              {slide.heading}

              <br />

              <span
                className="
                  tw:italic
                  tw:text-[#f4c7ce]
                "
              >
                {slide.highlight}
              </span>
            </motion.h1>

            {/* =========================================
                CTA
            ========================================= */}
            <motion.div
              initial={{
                opacity: 0,
                y: 20,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              transition={{
                duration: 0.65,
                delay: 0.4,
              }}
              className="tw:mt-7 tw:sm:mt-9"
            >
              <Link to={slide.ctaLink} className="tw:no-underline">
                <Button
                  unstyled
                  label={slide.cta}
                  className="
      tw:border!
      tw:border-[#800020]!
      tw:bg-[#800020]!
      tw:px-7!
      tw:py-3.5!
      tw:text-[11px]!
      tw:font-medium!
      tw:uppercase!
      tw:tracking-[0.18em]!
      tw:text-white!
      tw:shadow-none!
      tw:transition-all
      tw:duration-300
      tw:rounded-none!
      tw:hover:border-white!
      tw:hover:bg-white!
      tw:hover:text-[#800020]!
      tw:hover:font-bold

      tw:sm:px-9!
      tw:sm:py-4!
    "
                />
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </article>
    );
  };

  /**
   * ----------------------------------------
   * MEMOIZED TEMPLATE
   * ----------------------------------------
   */
  const memoizedTemplate = useMemo(() => slideTemplate, []);

  return (
    <section
      aria-label="Featured collections"
      className="
        tw:relative
        tw:w-full
        tw:overflow-hidden
        tw:bg-black
      "
    >
      <Carousel
        value={heroSlides}
        itemTemplate={memoizedTemplate}
        numVisible={1}
        numScroll={1}
        circular
        autoplayInterval={SLIDE_DURATION}
        showIndicators
        showNavigators
        pt={{
          root: {
            className: "tw:w-full",
          },

          content: {
            className: "tw:relative tw:w-full",
          },

          container: {
            className: "tw:w-full",
          },

          itemsContent: {
            className: "tw:w-full",
          },

          itemsContainer: {
            className: "tw:w-full",
          },

          item: {
            className: "tw:w-full",
          },

          previousButton: {
            className: `
              tw:absolute
              tw:left-5
              tw:top-1/2
              tw:z-30
              tw:flex
              tw:h-11
              tw:w-11
              tw:-translate-y-1/2
              tw:items-center
              tw:justify-center
              tw:rounded-full
              tw:border
              tw:border-white/40
              tw:bg-black/10
              tw:text-white
              tw:backdrop-blur-sm
              tw:transition-all
              tw:duration-300
              hover:tw:border-white
              hover:tw:bg-white/15
              tw:md:left-7
              tw:lg:left-10
            `,
          },

          nextButton: {
            className: `
              tw:absolute
              tw:right-5
              tw:top-1/2
              tw:z-30
              tw:flex
              tw:h-11
              tw:w-11
              tw:-translate-y-1/2
              tw:items-center
              tw:justify-center
              tw:rounded-full
              tw:border
              tw:border-white/40
              tw:bg-black/10
              tw:text-white
              tw:backdrop-blur-sm
              tw:transition-all
              tw:duration-300
              hover:tw:border-white
              hover:tw:bg-white/15
              tw:md:right-7
              tw:lg:right-10
            `,
          },

          indicators: {
            className: `
              tw:absolute
              tw:bottom-6
              tw:left-1/2
              tw:z-30
              tw:flex
              tw:-translate-x-1/2
              tw:items-center
              tw:gap-2
              tw:sm:bottom-8
            `,
          },

          indicator: {
            className: `
              tw:m-0
              tw:p-0
            `,
          },
        }}
      />
    </section>
  );
}
