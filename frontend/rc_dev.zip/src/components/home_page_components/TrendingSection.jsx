import { Button } from "primereact/button";
import ProductCard from "../ProductCard";
import { products } from "../../data/trending";

const TrendingSection = () => {

  return (
    <section
      className="
        tw:w-full
        tw:bg-white
        tw:px-5
        tw:py-16
        md:tw:px-10
        lg:tw:px-16
        xl:tw:px-20
      "
    >
      {/* Heading */}
      <div className="tw:text-center">
        <h2
          className="
            tw:m-0
            tw:font-serif
            tw:text-[28px]
            tw:font-normal
            tw:leading-tight
            tw:text-[#800020]
            md:tw:text-[30px]
          "
        >
          Trending Products
        </h2>
      </div>

      {/* Products */}
      <div
        className="
          tw:mx-auto
          tw:mt-14
          tw:grid
          tw:w-full
          tw:max-w-[1020px]
          tw:grid-cols-1
          tw:gap-x-8
          tw:gap-y-12
          sm:tw:grid-cols-2
          lg:tw:grid-cols-4
        "
      >
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {/* View All Button */}
      <div className="tw:mt-14 tw:flex tw:justify-center">
        <Button
          label="VIEW ALL"
          className="
            tw:rounded-none
            tw:border-0
            tw:bg-[#333333]
            tw:px-7
            tw:py-3
            tw:text-[9px]
            tw:font-normal
            tw:tracking-[0.5px]
            tw:text-white
            hover:tw:bg-[#222222]
          "
        />
      </div>
    </section>
  );
};

export default TrendingSection;