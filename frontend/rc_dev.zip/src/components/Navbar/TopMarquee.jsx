/* eslint-disable no-unused-vars */
import React from "react";

const TopMarquee = () => {
  const text = "CRAFTED TO MAKE EVERY MOMENT SPECIAL";

  return (
    <div className="tw:w-full tw:overflow-hidden tw:bg-black tw:text-white">
      <div className="top-marquee-track">
        <div className="top-marquee-content">
          <span>{text}</span>

          <span>{text}</span>

          <span>{text}</span>

          <span>{text}</span>
        </div>

        <div className="top-marquee-content">
          <span>{text}</span>

          <span>{text}</span>

          <span>{text}</span>

          <span>{text}</span>
        </div>
      </div>
    </div>
  );
};

export default TopMarquee;
