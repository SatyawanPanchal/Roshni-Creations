/* eslint-disable no-unused-vars */
import React from "react";
import TopMarquee from "./TopMarquee";
import Menubar from "./MenuBar";

const Navbar = () => {
  return (
    <>
      <header className="tw:sticky tw:top-0 tw:z-50 tw:w-full tw:bg-white">
        <TopMarquee />

        {/* Top Navbar */}
        <div className="tw:relative tw:flex tw:h-13.5 tw:items-center tw:justify-evenly tw:border-b tw:border-gray-100 tw:lg:gap-280">
          {/* Search */}
          {/* Search */}
          <button
            type="button"
            aria-label="Search"
            className="tw:group tw:relative tw:flex tw:cursor-pointer tw:items-center tw:justify-center tw:border-0 tw:bg-transparent tw:p-0"
          >
            <i
              className="pi pi-search tw:transition-transform tw:duration-200 tw:text-[#4a3338] tw:group-hover:scale-105"
              style={{ fontSize: "1.7rem" }}
            ></i>

            {/* Tooltip */}
            <span
              className="
      tw:pointer-events-none
      tw:absolute
      tw:top-[calc(100%+14px)]
      tw:left-1/2
      tw:z-100
      tw:-translate-x-1/2
      tw:-translate-y-1
      tw:whitespace-nowrap
      tw:border
      tw:border-[#e8e1df]
      tw:bg-white
      tw:px-3.5
      tw:py-2
      tw:font-serif
      tw:text-[12px]
      tw:tracking-[0.08em]
      tw:text-[#4a3338]
      tw:shadow-[0_5px_20px_rgba(0,0,0,0.08)]
      tw:opacity-0
      tw:transition-all
      tw:duration-200
      tw:group-hover:translate-y-0
      tw:group-hover:opacity-100
    "
            >
              Search
              {/* Small pointer */}
              <span
                className="
        tw:absolute
        tw:-top-1.25
        tw:left-1/2
        tw:h-2
        tw:w-2
        tw:-translate-x-1/2
        tw:rotate-45
        tw:border-l
        tw:border-t
        tw:border-[#e8e1df]
        tw:bg-white
      "
              ></span>
            </span>
          </button>

          {/* Logo / Brand */}
          <div className="tw:absolute tw:top-1/2 tw:left-1/2 tw:-translate-x-1/2 tw:-translate-y-1/2 tw:cursor-pointer">
            <h1 className="tw:m-0 tw:whitespace-nowrap tw:font-serif tw:text-[25px] tw:font-normal tw:leading-none tw:text-[#7D2638]">
              Roshni Creations
            </h1>
          </div>

          {/* Right Icons */}
          <div className="tw:flex tw:items-center tw:gap-4.5">
            {/* Account */}
            {/* Profile */}
            <button
              type="button"
              aria-label="Profile"
              className="tw:group tw:relative tw:flex tw:cursor-pointer tw:items-center tw:justify-center tw:border-0 tw:bg-transparent tw:p-0"
            >
              <i
                className="pi pi-user tw:transition-transform tw:text-[#4a3338] tw:duration-200 tw:group-hover:scale-105"
                style={{ fontSize: "1.7rem" }}
              ></i>

              <span
                className="
      tw:pointer-events-none
      tw:absolute
      tw:top-[calc(100%+14px)]
      tw:left-1/2
      tw:z-100
      tw:-translate-x-1/2
      tw:-translate-y-1
      tw:whitespace-nowrap
      tw:border
      tw:border-[#e8e1df]
      tw:bg-white
      tw:px-3.5
      tw:py-2
      tw:font-serif
      tw:text-[12px]
      tw:tracking-[0.08em]
      tw:text-[#4a3338]
      tw:shadow-[0_5px_20px_rgba(0,0,0,0.08)]
      tw:opacity-0
      tw:transition-all
      tw:duration-200
      tw:group-hover:translate-y-0
      tw:group-hover:opacity-100
    "
              >
                Profile
                <span
                  className="
        tw:absolute
        tw:-top-1.25
        tw:left-1/2
        tw:h-2
        tw:w-2
        tw:-translate-x-1/2
        tw:rotate-45
        tw:border-l
        tw:border-t
        tw:border-[#e8e1df]
        tw:bg-white
      "
                ></span>
              </span>
            </button>

            {/* Shopping Bag */}
            {/* Shopping Bag */}
            <button
              type="button"
              aria-label="Shopping Bag"
              className="tw:group tw:relative tw:flex tw:cursor-pointer tw:items-center tw:justify-center tw:border-0 tw:bg-transparent tw:p-0"
            >
              <i
                className="pi pi-shopping-bag tw:transition-transform tw:text-[#4a3338] tw:duration-200 tw:group-hover:scale-105"
                style={{ fontSize: "1.7rem" }}
              ></i>

              <span
                className="
      tw:pointer-events-none
      tw:absolute
      tw:top-[calc(100%+14px)]
      tw:right-0
      tw:z-100
      tw:-translate-y-1
      tw:whitespace-nowrap
      tw:border
      tw:border-[#e8e1df]
      tw:bg-white
      tw:px-3.5
      tw:py-2
      tw:font-serif
      tw:text-[12px]
      tw:tracking-[0.08em]
      tw:text-[#4a3338]
      tw:shadow-[0_5px_20px_rgba(0,0,0,0.08)]
      tw:opacity-0
      tw:transition-all
      tw:duration-200
      tw:group-hover:translate-y-0
      tw:group-hover:opacity-100
    "
              >
                Cart
                <span
                  className="
        tw:absolute
        tw:-top-1.25
        tw:right-3
        tw:h-2
        tw:w-2
        tw:rotate-45
        tw:border-l
        tw:border-t
        tw:border-[#e8e1df]
        tw:bg-white
      "
                ></span>
              </span>
            </button>
          </div>
        </div>
      </header>
      <Menubar/>
    </>
  );
};

export default Navbar;
