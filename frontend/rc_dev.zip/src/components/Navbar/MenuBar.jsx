const Menubar = () => {
  const menuItems = [
    { label: "Jewellery", dropdown: true },
    { label: "Heavy Jewellery" },
    { label: "Shining Kundans" },
    { label: "Kashmere Watch" },
    { label: "Festive Edits" },
    { label: "Minimal Daily Wear" },
    { label: "Beaded & Crystal" },
    { label: "Resin & Flowers" },
    { label: "Temple Inspired" },
  ];

  return (
    <nav className="tw:flex tw:h-10 tw:w-full tw:items-center tw:justify-center tw:border-b tw:border-gray-100 tw:bg-white">
      <div className="tw:flex tw:items-center tw:gap-6">
        {menuItems.map((item) => (
          <button
            key={item.label}
            type="button"
            className="
              tw:group
              tw:flex
              tw:cursor-pointer
              tw:items-center
              tw:gap-[5px]
              tw:border-0
              tw:bg-transparent
              tw:p-0
              tw:font-serif
              tw:text-[14px]
              tw:font-normal
              tw:tracking-[0.01em]
              tw:text-[#4b4141]
              tw:transition-colors
              tw:duration-200
              hover:tw:text-[#7D2638]
            "
          >
            <span>{item.label}</span>

            {item.dropdown && (
              <i className="pi pi-chevron-down tw:mt-[1px] tw:text-[7px] tw:transition-transform tw:duration-200 group-hover:tw:translate-y-[1px]"></i>
            )}
          </button>
        ))}
      </div>
    </nav>
  );
};

export default Menubar;
