const ProductCard = ({ product }) => {
  return (
    <div className="tw:w-full tw:text-center">
      {/* Product Image */}
      <div className="tw:aspect-[0.8] tw:w-full tw:overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="tw:h-full tw:w-full tw:object-cover"
        />
      </div>

      {/* Product Details */}
      <div className="tw:mt-8">
        <h3
          className="
            tw:mx-auto
            tw:max-w-[180px]
            tw:truncate
            tw:font-serif
            tw:text-[10px]
            tw:font-normal
            tw:tracking-[0.2px]
            tw:text-[#333333]
          "
          title={product.name}
        >
          {product.name}
        </h3>

        <p
          className="
            tw:mt-1.5
            tw:text-[12px]
            tw:font-medium
            tw:tracking-[0.3px]
            tw:text-[#222222]
          "
        >
          Rs. {product.price}
        </p>
      </div>
    </div>
  );
};

export default ProductCard;