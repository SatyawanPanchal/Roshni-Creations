/* eslint-disable no-unused-vars */
import React from "react";
import HeroSlider from "../components/home_page_components/HeroSlider";
import TrendingSection from "../components/home_page_components/TrendingSection";

const Home = () => {
  return (
    <>
      <div>
        <HeroSlider/>
        <TrendingSection/>
      </div>
    </>
  );
};

export default Home;
